# Isolate Anticheat
The most advanced minecraft bedrock edition anticheat for pvp style servers

# What is Isolate?
Isolate Anticheat is an advanced Minecraft Bedrock Edition anticheat created using the scripting API with PvP and Minigame realms in mind. The anticheat has some of the best combat, movement, world and packet checks in the market and some even consider it the best.

# Discord
Join the [Discord](https://discord.gg/YQXUXMHwbM) for more updates, news and support.


# How to install Isolate Anticheat
If you need to learn how to install isolate anticheat click [Here](https://github.com/Dream23322/Isolate-Anticheat/blob/main/hti.md)



Want to join the dev team? dm 4urxra on discord!
