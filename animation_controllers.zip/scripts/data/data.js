export default
{
    unbanQueue: [],
    recentLogs: [],
    recentAdminLogs: [],
    banList: [],
    entitiesSpawnedInLastTick: 0,
    loaded: false,
    checkedModules: {
        autoclicker: false
    }
};
