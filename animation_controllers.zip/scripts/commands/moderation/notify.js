/**
 * @name notify
 * @param {object} message - Message object
 */
export function notify(message) {
    // validate that required params are defined
    if(typeof message !== "object") throw TypeError(`message is type of ${typeof message}. Expected "object".`);

    const player = message.sender;

    if(player.hasTag("notify")) {
        player.removeTag("notify");

        player.sendMessage("§r§j[§uIsolate§j]§r You will now no longer receive cheat notifications.");
        player.runCommandAsync(`tellraw @a[tag=op] {"rawtext":[{"text":"§r§j[§uIsolate§j]§r ${player.name} has §4disabled§r cheat notifications."}]}`);
    } else {
        player.addTag("notify");

        player.sendMessage("§r§j[§uIsolate§j]§r You will now receive cheat notifications.");
        player.runCommandAsync(`tellraw @a[tag=op] {"rawtext":[{"text":"§r§j[§uIsolate§j]§r ${player.name} has §aenabled§r cheat notifications."}]}`);
    }
}
