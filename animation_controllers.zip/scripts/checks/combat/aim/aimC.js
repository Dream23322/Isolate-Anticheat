import * as Minecraft from "@minecraft/server";
import { flag, getScore, setScore } from "../../../util";
import config from "../../../data/config.js";
import { fastAbs } from "../../../utils/fastMath.js";
import { getDeltaPitch, getDeltaYaw, getLastDeltaPitch, getLastDeltaYaw } from "./aimData.js";
import { allowedPlatform } from "../../../utils/platformUtils.js";
import { EXPANDER, gcd, getgcd } from "../../../utils/mathUtil.js";

export function aim_c(player) {
    if(config.modules.aimC.enabled) {
        // Platform check
        if(!allowedPlatform(player, config.modules.aimC.AP)) return;

        // Variables
        let bufferVal = getScore(player, "aim_c_buffer", 0);


        const deltaPitch = getDeltaPitch(player);
        const deltaYaw = getDeltaYaw(player);

        const lastDeltaPitch = getLastDeltaPitch(player);
        const lastDeltaYaw = getLastDeltaYaw(player);


        if(deltaPitch < 1.0 && deltaYaw < 1.0) return false;
        const divisorYaw = gcd((deltaYaw * EXPANDER), (lastDeltaYaw * EXPANDER));
        const divisorPitch = gcd((deltaPitch * EXPANDER), (lastDeltaPitch * EXPANDER));
    
        const maxConstant = Math.max(divisorPitch, divisorYaw) / EXPANDER;
        // Test rotation
        if(
            maxConstant < 0.0078125 &&
            (player.hasTag("attacking") || !config.modules.aimC.needHit)
        ) {
            // Increment the buffer score for the player
            setScore(player, "aim_c_buffer", bufferVal + 1);
            bufferVal++;
            // Log the buffer score for debugging purposes
            console.warn(`${player.name} | Aim C Buffer: ${getScore(player, "aim_c_buffer", 0)}`);
        }
        // Check if the buffer score exceeds the threshold for the Aim C module
        if(bufferVal > config.modules.aimC.buffer) {
            // Flag the player with the Aim C module and the rotation data
            flag(player, "Aim", "C", "Combat (BETA)", "maxConstant", `${maxConstant},DivYaw=${divisorYaw},DivPitch=${divisorPitch},Yaw=${deltaYaw},Pitch=${deltaPitch}`, false);
            // Reset the buffer score for the player
            setScore(player, "aim_c_buffer", 0);
        }
    }
}