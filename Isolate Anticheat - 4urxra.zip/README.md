# Isolate Anticheat
The most advanced minecraft bedrock edition anticheat for pvp style servers

# What is Isolate?
Isolate Anticheat is the most advanced minecraft bedrock edition anticheat, it has the best fly, killaura, speed, reach and exploit checks in an anticheat. It was made because there are issues in scythe that seem to not be getting fixed.

# Discord
Join the [Discord](https://discord.gg/YQXUXMHwbM) for more updates, news and support.


# How to install Isolate Anticheat
If you need to learn how to install isolate anticheat click [Here](https://github.com/Dream23322/Isolate-Anticheat/blob/main/hti.md)



Want to join the dev team? dm 4urxra on discord!